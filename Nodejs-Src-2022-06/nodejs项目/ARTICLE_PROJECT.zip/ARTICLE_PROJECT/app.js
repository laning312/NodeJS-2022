const express = require("express");
const app = express();
const cors = require("cors");
app.use(cors());  // 解决跨域
// 解析post传值过来获取不到的问题
app.use(express.urlencoded({ extended: true }));

//引入express-jwt对路由进行鉴权  解析鉴权令牌
const { expressjwt: jwt } = require("express-jwt");
app.use(jwt({
    secret: 'passlove',  //密文 自定义
    algorithms: ['HS256'],   //加密算法
}).unless({ path: [/^\/api\//, /^\/images\//] }))


// 配置静态资源（图片等）的访问 
// 第一个参数表示客户端访问时的路径，第二个为服务器端访问的路径
app.use('/images/', express.static('uploads/images/'));


//引入、注册路由
const usersRouter = require("./router/users.js");
app.use("/api", usersRouter);
const userinfoRouter = require("./router/users_info.js");
app.use("/my", userinfoRouter);
const articleTypeRouter = require("./router/article_type.js");
app.use("/my", articleTypeRouter);
const articleRouter = require("./router/article.js");
app.use("/my", articleRouter);


//配置全局错误中间件  只要校验错误的信息全在这里报出
const Joi = require('joi');
app.use((err, req, res, next) => {
    //Joi 参数校验失败
    if (err instanceof Joi.ValidationError) {
        return res.send({
            status: 1,
            message: err.message
        })
    }
    //未知错误
    res.send({
        status: 1,
        message: err.message
    })
})

app.listen(3008, err => {
    if (!err) {
        console.log("3008 is running");
    }
})