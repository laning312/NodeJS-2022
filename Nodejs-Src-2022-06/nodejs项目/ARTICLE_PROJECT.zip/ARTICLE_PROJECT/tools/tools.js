/* 本模块为工具包，所用到的小工具全部在这里定义，然后导出使用 */
const crypto=require("crypto");
//md5加密
function cryptPwd(password) {
    let md5 = crypto.createHash('md5');
    return md5.update(password).digest('hex');
}
module.exports={
    cryptPwd
}