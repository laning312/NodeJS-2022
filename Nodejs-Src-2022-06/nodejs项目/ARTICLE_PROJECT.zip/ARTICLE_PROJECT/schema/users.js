/* 此模块中写用户数据校验规则，用joi包来写 */
const joi=require("joi");
//注册时的规则定义：
const regUserSchema={
    //说明是post传值，校验body获取的数据
    body:{
        username:joi.string().pattern(/^[a-zA-Z0-9\u4e00-\u9fa5]{2,10}$/).required(),
        password:joi.string().min(3).max(6).required()
    }
}
//登录时的规则定义：
const loginUserSchema={
    body:{
        username:joi.string().pattern(/^[a-zA-Z0-9\u4e00-\u9fa5]{2,10}$/).required(),
        password:joi.string().min(3).max(6).required()
    }
}
//更新用户的规则
const upUsersinfoSchema={
    body:{
        id:joi.number().required(),
        nickname:joi.string().pattern(/^[a-zA-Z0-9\u4e00-\u9fa5]{2,10}$/).required(),
        email:joi.string().email().required()
    }
}

//重置密码规则
const resetPsdSchema={
    body:{
        oldPwd:joi.string().min(3).max(6).required(),
        newPwd:joi.string().min(3).max(6).required()
    }
}

//更新图像规则
const updateimgSchema={
    body:{
        avatar:joi.string().required()
    }
}

module.exports={
    regUserSchema,
    loginUserSchema,
    upUsersinfoSchema,
    resetPsdSchema,
    updateimgSchema
}