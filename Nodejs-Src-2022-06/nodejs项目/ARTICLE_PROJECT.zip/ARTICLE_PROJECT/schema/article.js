/* 此模块中写文章相关内容校验规则，用joi包来写 */
const { string } = require("joi");
const joi = require("joi");
//新增文章分类的校验规则
const addArticletypeSchema = {
    //说明是post传值，校验body获取的数据
    body: {
        name: joi.string().pattern(/^[a-zA-Z0-9_\u4e00-\u9fa5]{2,20}$/).required(),
        alias: joi.string().pattern(/^[a-zA-Z0-9_\u4e00-\u9fa5]{2,20}$/).required()
    }
}
//通过id 删 查
const deltypeByidSchema = {
    params: {
        id: joi.string().pattern(/^[0-9]{1,}$/).required(),
    }
}

//通过id更新分类信息
const uptypeByidSchema = {
    body: {
        id: joi.string().pattern(/^[0-9]{1,}$/).required(),
        name: joi.string().pattern(/^[a-zA-Z0-9_\u4e00-\u9fa5]{2,20}$/).required(),
        alias: joi.string().pattern(/^[a-zA-Z0-9_\u4e00-\u9fa5]{2,20}$/).required()
    }
}

//新增文章规则
const addarticleSchema = {
    body: {
        title: joi.string().required(),
        cate_id: joi.number().required(),
        content: joi.string().required(),
        // cover_img: joi.string().required(),
        state: joi.string().pattern(/^[\u4e00-\u9fa5]{2,4}$/).required()
    }
}

module.exports = {
    addArticletypeSchema,
    deltypeByidSchema,
    uptypeByidSchema,
    addarticleSchema
}

