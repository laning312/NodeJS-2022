/* 文章管理模块的路由分配 */
const express = require("express");
const router = express.Router();
const articleHandles = require("../router_handle/article.js");


//处理文件上传需要用到的模块、包
const path = require("path");
const multer = require('multer');
const { v4: uuidv4 } = require("uuid");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, "../uploads/images"));
  },
  filename: function (req, file, cb) {
    // console.log(req.body)
    //生成随机名称
    const tmp = uuidv4().replaceAll('-', '');
    //path.extname  获取文件的后缀名
    cb(null, tmp + req.body.extname)
  }
});
const upload = multer({ storage: storage });



const expressjoi = require("@escook/express-joi");
const userinfoSchema = require("../schema/article.js");

//发布新文章路由
router.post("/article/add", upload.single('cover_img'), expressjoi(userinfoSchema.addarticleSchema), articleHandles.addArticleHandle);
//获取文章的列表数据
router.get("/article/list", articleHandles.getArticlelistHandle);
//根据Id删除文章数据
router.get("/article/delete/:id", expressjoi(userinfoSchema.deltypeByidSchema), articleHandles.delArticleByid);
//根据Id获取文章详情
router.get("/article/:id", expressjoi(userinfoSchema.deltypeByidSchema), articleHandles.getArticlelistByid);
//根据Id更新文章信息
router.post("/article/edit", upload.single("cover_img"), articleHandles.upArticleByid);

module.exports = router;