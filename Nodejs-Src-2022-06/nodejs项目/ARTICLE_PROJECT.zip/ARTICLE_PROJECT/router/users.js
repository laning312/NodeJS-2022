////用户模块_登录注册路由配置
const express=require("express");
const router=express.Router();
//引入路由的处理函数
const usersHandle=require("../router_handle/users.js");


//导入express-joi中间件 处理编好的规则的验证
const expressjoi=require("@escook/express-joi");
// 6. 导入所需的schema 验证用户的规则
const UsersSchema = require("../schema/users.js");

//注册接口
router.post("/reg",expressjoi(UsersSchema.regUserSchema),usersHandle.regUser);
//登录接口
router.post("/login",expressjoi(UsersSchema.loginUserSchema),usersHandle.loginUser);

module.exports=router;