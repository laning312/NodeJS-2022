//用户模块_个人中心路由配置
const express = require("express");
const router = express.Router();
const UsersinfoHandle = require("../router_handle/users_info.js");

const expressjoi=require("@escook/express-joi");
const userinfoSchema=require("../schema/users.js");
//获取
router.get("/userinfo", UsersinfoHandle.getUsersinfo);
//更新
router.post("/userinfo",expressjoi(userinfoSchema.upUsersinfoSchema),UsersinfoHandle.updateUsersinfo);
//重置密码
router.post("/updatepwd",expressjoi(userinfoSchema.resetPsdSchema),UsersinfoHandle.resetPsdUsersinfo);
//更换图像
router.post("/update/avatar",expressjoi(userinfoSchema.updateimgSchema),UsersinfoHandle.updateImg);


module.exports = router;