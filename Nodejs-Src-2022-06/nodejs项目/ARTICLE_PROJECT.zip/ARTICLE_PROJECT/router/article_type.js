//文章类别管理模块路由配置
const express=require("express");
const router=express.Router();
const articleTypeHandle=require("../router_handle/article_type.js");

//导入express-joi中间件 处理编好的规则的验证
const expressjoi=require("@escook/express-joi");
// 6. 导入所需的schema 验证的规则
const articleSchema = require("../schema/article.js");

//获取文章分类列表
router.get("/article/cates",articleTypeHandle.getArticleList);
//新增文章分类
router.post("/article/addcates",expressjoi(articleSchema.addArticletypeSchema),articleTypeHandle.addArticleType);
//根据Id删除文章分类
router.get("/article/deletecate/:id",expressjoi(articleSchema.deltypeByidSchema),articleTypeHandle.delArticletypeByid);
//根据Id获取文章分类数据
router.get("/article/cates/:id",expressjoi(articleSchema.deltypeByidSchema),articleTypeHandle.getArticletypeByid);
//根据Id更新文章分类数据
router.post("/article/updatecate",expressjoi(articleSchema.uptypeByidSchema),articleTypeHandle.upArticletypeByid);



module.exports=router;