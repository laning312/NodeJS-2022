//用户模块_个人中心路由逻辑
const db = require("../db/db.js");

//获取用户基本信息
let getUsersinfo = (req, res) => {
    let id = req.auth.id;
    // console.log(id);
    const sql = "select * from t_user where id=?";
    db.query(sql, id, (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.length === 0) return res.send({ status: 1, message: "用户没注册" });
        return res.send({
            status: 0,
            message: '获取用户基本信息成功！',
            data: {
                id: results[0].id,
                username: results[0].username,
                nickname: results[0].nickname,
                email: results[0].email,
                headpic: results[0].headpic,
            }
        })
    })
}



//更新用户的基本信息
let updateUsersinfo = (req, res) => {
    let { id, nickname, email } = req.body;
    let oldid = req.auth.id;
    if (id != oldid) {
        return res.send({ status: 1, message: "不是当前用户，无法修改" });
    } else {
        const sql = "update t_user set nickname=?,email=? where id=?";
        db.query(sql, [nickname, email, id], (err, results) => {
            if (err) return res.send({ status: 1, message: err });
            if (results.affectedRows != 1) return res.send({ status: 1, message: "修改失败" });
            return res.send({
                status: 0,
                message: '修改用户信息成功！',
            })
        })
    }
}



//重置密码
let resetPsdUsersinfo = (req, res) => {
    // res.send("ok");
    let { oldPwd, newPwd } = req.body;
    // console.log(oldPwd, newPwd);
    let id = req.auth.id;
    const selsql = "select * from t_user where password=md5(?) and id=?";
    db.query(selsql, [oldPwd, id], (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.length === 0) return res.send({ status: 1, message: "密码不正确" });
        const sql = "update t_user set password=md5(?) where id=?";
        db.query(sql, [newPwd, id], (err, results) => {
            if (err) return res.send({ status: 1, message: err });
            if (results.affectedRows != 1) return res.send({ status: 1, message: "更新密码失败" });
            return res.send({
                status: 0,
                message: '更新密码成功！',
            })
        })
    })
}



//更换图像逻辑
let updateImg = (req, res) => {
    let { avatar } = req.body;
    let id = req.auth.id;
    const sql = "update t_user set headpic=? where id=?";
    db.query(sql, [avatar, id], (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.affectedRows != 1) return res.send({ status: 1, message: "更新图像失败" });
        return res.send({
            status: 0,
            message: '更新图像成功！',
        })
    })
}

module.exports = {
    getUsersinfo,
    updateUsersinfo,
    resetPsdUsersinfo,
    updateImg
};