//文章类别管理模块路由逻辑
const db = require("../db/db.js");


//获取文章分类列表逻辑
let getArticleList = (req, res) => {
    const sql = "select id as Id,catename as name,alias,is_delete from t_article_category where is_delete=0";
    db.query(sql, (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.length === 0) return res.send({ status: 1, message: "没有可获取的列表" });
        return res.send({
            status: 0,
            message: '获取文章分类列表成功！',
            data: results
        })
    })
}




//新增文章分类逻辑
let addArticleType = (req, res) => {
    let { name, alias } = req.body;
    const selsql = "select * from t_article_category where catename=? or alias=?";
    db.query(selsql, [name, alias], (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.length !== 0) return res.send({ status: 1, message: "此分类名或别名已注册" });
        const sql = "insert into t_article_category (catename,alias,is_delete) values (?,?, 0)";
        db.query(sql, [name, alias], (err, results) => {
            if (err) return res.send({ status: 1, message: err });
            if (results.affectedRows != 1) return res.send({ status: 1, message: "新增文章分类失败！" });
            return res.send({
                status: 0,
                message: '新增文章分类成功！'
            })
        })
    })
}




//根据Id删除文章分类逻辑
let delArticletypeByid = (req, res) => {
    let id = req.params.id;
    const sql = "update t_article_category set is_delete=1 where id=?";
    db.query(sql, id, (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.affectedRows != 1) return res.send({ status: 1, message: "删除文章分类失败！" });
        return res.send({
            status: 0,
            message: '删除文章分类成功！'
        })
    })
}




//根据Id获取文章分类数据逻辑
let getArticletypeByid = (req, res) => {
    let id = req.params.id;
    const sql = "select * from t_article_category where id=?";
    db.query(sql, id, (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.length === 0) return res.send({ status: 1, message: "没有此文章分类数据！" });
        return res.send({
            status: 0,
            message: '获取文章分类数据成功！',
            data: {
                Id: results[0].id,
                name: results[0].catename,
                alias: results[0].alias,
                is_delete: results[0].is_delete
            }
        })
    })
}




//根据Id更新文章分类数据
let upArticletypeByid = (req, res) => {
    let { id, name, alias } = req.body;
    const selsql1 = "select * from t_article_category where id=?";
    db.query(selsql1, id, (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.length === 0) return res.send({ status: 1, message: "没有此文章分类数据！" });
        const selsql2 = "select * from t_article_category where catename=? or alias=?";
        db.query(selsql2, [name, alias], (err, results) => {
            if (err) return res.send({ status: 1, message: err });
            if (results.length !== 0) return res.send({ status: 1, message: "此分类名或别名已注册" });
            const sql = "update t_article_category set catename=?,alias=? where id=?";
            db.query(sql, [name, alias, id], (err, results) => {
                if (err) return res.send({ status: 1, message: err });
                if (results.affectedRows != 1) return res.send({ status: 1, message: "更新失败！" });
                return res.send({
                    status: 0,
                    message: '更新分类信息成功！'
                })
            })
        })
    })
}


module.exports = {
    getArticleList,
    addArticleType,
    delArticletypeByid,
    getArticletypeByid,
    upArticletypeByid,
}