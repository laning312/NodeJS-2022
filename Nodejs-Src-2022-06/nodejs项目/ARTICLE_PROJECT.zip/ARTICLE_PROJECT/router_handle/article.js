/* 文章管理模块的路由逻辑 */
const db = require("../db/db.js");

//发布新文章路由逻辑
let addArticleHandle = (req, res) => {
    const articleInfo = {
        ...req.body,
        pub_date: new Date().toLocaleString(),
        author_id: req.auth.id,
        is_delete: 0,
        cover_img: '/images/' + req.file.filename
    }
    //express 支持的sql插入多文件时的简易写法
    const sql = 'insert into t_article set ?';
    db.query(sql, articleInfo, (err, results) => {
        if (err) return res.send({ status: 1, message: err })
        if (results.affectedRows === 0) return res.send({ status: 1, message: '发布文章失败' })
        return res.send({ status: 0, message: '发布成功' })
    })
}




//获取文章的列表数据
let getArticlelistHandle = (req, res) => {
    let { pagenum, pagesize, cate_id, state } = req.query;
    let pnum = (parseInt(pagenum) - 1) * pagesize;
    if (pagenum === undefined || pagesize === undefined || pagenum === "" || pagesize === "") {
        return res.send({ status: 1, message: '参数错误' });
    } else {
        let sql = `select ta.id as Id,title,pub_date, state, catename as cate_name 
        from t_article ta , t_article_category tac 
        where ta.cate_id = tac.id and author_id=? and ta.is_delete=0 `;
        if (state) sql += `and state='${state}' `;
        if (cate_id) sql += `and cate_id=${cate_id} `;
        sql += "limit ?,?";
        db.query(sql, [req.auth.id, pnum, parseInt(pagesize)], (err, results) => {
            // console.log(err)
            if (err) return res.send({ status: 1, message: err });
            if (results.length === 0) return res.send({ status: 1, message: "没有文章列表" });
            return res.send({
                status: 0,
                message: '获取文章列表成功！',
                data: results
            })
        })
    }
}




//根据Id删除文章数据
let delArticleByid = (req, res) => {
    let id = req.params.id;
    const sql = "update t_article set is_delete=1 where id=?";
    db.query(sql, id, (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.affectedRows != 1) return res.send({ status: 1, message: "删除失败！" });
        return res.send({
            status: 0,
            message: '删除成功！'
        })
    })
}




//根据Id获取文章详情
let getArticlelistByid = (req, res) => {
    let id = req.params.id;
    const sql = "select * from t_article where id=?";
    db.query(sql, id, (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.length === 0) return res.send({ status: 1, message: "没有此文章数据！" });
        return res.send({
            status: 0,
            message: '获取文章成功！',
            data: {
                Id: results[0].id,
                title: results[0].title,
                content: results[0].content,
                cover_img: results[0].cover_img,
                pub_date: results[0].pub_date,
                state: results[0].state,
                is_delete: results[0].is_delete,
                cate_id: results[0].cate_id,
                author_id: results[0].author_id
            }
        })
    })
}




//根据Id更新文章信息
let upArticleByid = (req, res) => {
    let author_id = req.auth.id;
    let { id, title, cate_id, content, state } = req.body;
    console.log(id)
    let cover_img = '/images/' + req.file.filename;
    const selsql = "select * from t_article where author_id=? and id=?";
    db.query(selsql, [author_id, id], (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.length === 0) return res.send({ status: 1, message: "没有此文章数据！" });
        const upsql = "update t_article set title=?,cate_id=?,content=?,cover_img=?,state=? where id=?";
        db.query(upsql, [title, cate_id, content, cover_img, state, id], (err, results) => {
            if (err) return res.send({ status: 1, message: err });
            if (results.affectedRows != 1) return res.send({ status: 1, message: "修改文章失败！" });
            return res.send({
                status: 0,
                message: '修改文章成功！'
            })
        })
    })
}



module.exports = {
    addArticleHandle,
    getArticlelistHandle,
    delArticleByid,
    getArticlelistByid,
    upArticleByid
}