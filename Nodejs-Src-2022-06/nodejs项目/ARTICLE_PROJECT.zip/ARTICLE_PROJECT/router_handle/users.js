//用户模块_登录注册路由逻辑
const db = require("../db/db.js");
const tools = require("../tools/tools.js");
//引入鉴权所需要的包  生成鉴权令牌
const jwt = require("jsonwebtoken");


//用户注册处理逻辑
let regUser = (req, res) => {
    // console.log(req.body);
    let { username, password} = req.body;
    //先查询有无已注册的用户
    let checksql = "select * from t_user where username=?";
    db.query(checksql, username, (err, results) => {
        if (err) return res.send({ status: 1, message: err });
        if (results.length > 0) return res.send({ status: 1, message: "用户名已注册" });
        //用户名无注册 可用
        password = tools.cryptPwd(password);
        let sql = "insert into t_user values (null,?,?,null,null,null)";
        db.query(sql, [username, password], (err, results) => {
            if (err) return res.send({ status: 1, message: err });
            if (results.affectedRows != 1) return res.send({ status: 1, message: "注册失败" });
            res.send({
                status: 0,
                message: "注册成功"
            })
        })
    })
}


//用户登录处理逻辑
let loginUser = (req, res) => {
    // console.log(req.body);
    let {username,password}=req.body;
    let sql="select * from t_user where username=? and password=md5(?)";
    db.query(sql,[username,password],(err,results)=>{
        if(err) return res.send({ status: 1, message: err });
        if(results.length===0) return res.send({status: 1,message:"用户名或密码错误"});
        //用户和密码都正确，开始产生令牌，对之后的操作功能进行鉴权
        let token=jwt.sign({id:results[0].id,username:results[0].username},"passlove",{expiresIn:"1h"});
        return res.send({
            status: 0,
            message: '登录成功',
            token: 'bearer ' + token
        })
    })
}

module.exports = {
    regUser,
    loginUser
};